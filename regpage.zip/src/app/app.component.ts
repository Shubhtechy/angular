import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'regpage';



  // contactForm = new FormGroup({

  //   firstname: new FormControl("",[Validators.required,Validators.minLength(4)]),

  //   lastname: new FormControl("sdfsd"),

  //   email: new FormControl(),

  //   gender: new FormControl(),

  //   isMarried: new FormControl(),

  //   country: new FormControl()

  // })



  constructor() { }



  ngOnInit(): void {

  }

  /*

  onSubmit(value:any)

  {

    console.log(value);

  } 

  */



  

  // onSubmit() {

  //   console.log(this.contactForm.value);

  // } 

}


