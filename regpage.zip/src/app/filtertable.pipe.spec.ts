import { FiltertablePipe } from './filtertable.pipe';

describe('FiltertablePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltertablePipe();
    expect(pipe).toBeTruthy();
  });
});
