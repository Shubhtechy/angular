import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
  name: 'filtertable'
})
export class FiltertablePipe implements PipeTransform {

  transform(value: unknown, ...args: unknown[]): unknown {
    return null;
  }

}
